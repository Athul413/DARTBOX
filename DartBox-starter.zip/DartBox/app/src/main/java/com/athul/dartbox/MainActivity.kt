package com.athul.dartbox

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var status: TextView
    private var currentName = "main.dart"
    private val createFileRequest = 4101
    private val openFileRequest = 4102

    private val starterCode = """import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(
        body: Center(
          child: Text('Hello from DartBox!'),
        ),
      ),
    );
  }
}
"""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        editor.setText(getPreferences(MODE_PRIVATE).getString("draft", starterCode))
        currentName = getPreferences(MODE_PRIVATE).getString("filename", "main.dart") ?: "main.dart"
        status.text = "$currentName  •  Draft restored"
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF10131B.toInt())
            setPadding(dp(12), dp(10), dp(12), dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "DartBox"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(actionButton("Open", 0xFF30394B.toInt()) { openDartFile() })
        header.addView(actionButton("Export", 0xFF315C49.toInt()) { exportDartFile() })
        root.addView(header)

        val fileBar = TextView(this).apply {
            text = "  ◈  main.dart"
            setTextColor(0xFFB9C5D8.toInt())
            textSize = 13f
            setPadding(dp(8), dp(10), dp(8), dp(10))
            setBackgroundColor(0xFF1A2030.toInt())
        }
        root.addView(fileBar)

        val editorScroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(0xFF171C28.toInt())
        }
        editor = EditText(this).apply {
            setTextColor(0xFFE5E9F0.toInt())
            setHintTextColor(0xFF78849A.toInt())
            hint = "// Start writing Dart..."
            textSize = 14f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(12), dp(14), dp(12), dp(20))
            setBackgroundColor(0xFF171C28.toInt())
            setSingleLine(false)
            isVerticalScrollBarEnabled = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setHorizontallyScrolling(true)
            setTextIsSelectable(true)
        }
        editorScroll.addView(editor)
        root.addView(editorScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(6))
        }
        actions.addView(actionButton("Save draft", 0xFF30394B.toInt()) { saveDraft() },
            LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(6) })
        actions.addView(actionButton("Run / Preview", 0xFF39785A.toInt()) {
            Toast.makeText(this, "Flutter runtime is planned for a later milestone. No fake output is shown.", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(6) })
        root.addView(actions)

        status = TextView(this).apply {
            text = "Ready"
            textSize = 12f
            setTextColor(0xFF91A0B8.toInt())
            setPadding(dp(4), dp(5), dp(4), dp(3))
        }
        root.addView(status)
        setContentView(root)
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(color))
            setOnClickListener { action() }
        }
    }

    private fun saveDraft() {
        getPreferences(MODE_PRIVATE).edit()
            .putString("draft", editor.text.toString())
            .putString("filename", currentName)
            .apply()
        status.text = "$currentName  •  Saved locally"
        Toast.makeText(this, "Draft saved on this device", Toast.LENGTH_SHORT).show()
    }

    private fun exportDartFile() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/x-dart"
            putExtra(Intent.EXTRA_TITLE, currentName)
        }
        startActivityForResult(intent, createFileRequest)
    }

    private fun openDartFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, openFileRequest)
    }

    @Deprecated("Using activity result API kept minimal for starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            if (requestCode == createFileRequest) {
                contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(editor.text.toString().toByteArray(Charsets.UTF_8))
                }
                status.text = "Exported $currentName"
                Toast.makeText(this, "Dart file exported", Toast.LENGTH_SHORT).show()
            } else if (requestCode == openFileRequest) {
                val content = contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input)).readText()
                } ?: ""
                editor.setText(content)
                currentName = uri.lastPathSegment?.substringAfterLast('/') ?: "main.dart"
                status.text = "Opened $currentName"
                saveDraft()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "File error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
