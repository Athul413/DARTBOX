# DartBox

DartBox is an early native Android starter project for a mobile Dart/Flutter coding environment.

## Current milestone (0.1.0)

- Native Android shell written in Kotlin.
- Multiline monospace Dart editor.
- Restores the last draft after closing/reopening the app.
- Opens an existing text/Dart file through Android's document picker.
- Exports the current editor contents as a `.dart` file.
- GitHub Actions workflow builds a debug APK.

## Important limitations

This first milestone is an editor shell, not a Dart or Flutter compiler.

- The Run / Preview button intentionally does not fabricate output.
- There is no embedded Dart VM, Flutter engine, widget renderer, package resolver, or hot reload yet.
- Exporting `main.dart` alone does not make a complete Flutter project. A later milestone will add project scaffolding (`pubspec.yaml`, `lib/main.dart`, assets) and a real build pipeline.

## Build APK on GitHub

1. Create a GitHub repository named `DartBox`.
2. Upload the contents of this folder to the repository root (not the enclosing ZIP folder).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build DartBox APK** or push to `main`.
5. Open the successful workflow run and download the `DartBox-debug-apk` artifact.
6. Extract the artifact ZIP; install `app-debug.apk` on your Android device.

## Build requirements

- JDK 17
- Gradle 8.9
- Android SDK platform 35 and build tools (GitHub runner setup provides the Android SDK)

## Project structure

```text
DartBox/
├── .github/workflows/build-apk.yml
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/athul/dartbox/MainActivity.kt
├── build.gradle
├── gradle.properties
├── settings.gradle
└── README.md
```
